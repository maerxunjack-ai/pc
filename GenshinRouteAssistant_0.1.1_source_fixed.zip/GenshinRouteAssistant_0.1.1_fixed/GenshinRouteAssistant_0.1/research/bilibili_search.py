from urllib.parse import urlparse
import json
import re
import urllib.request

USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/128 Safari/537.36"

def inspect_bilibili_url(url: str) -> dict:
    """Best-effort public page metadata fetch. Does not bypass login, CAPTCHA, or access restrictions."""
    result = {"summary": "", "text": ""}
    try:
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Referer": "https://www.bilibili.com/"})
        with urllib.request.urlopen(req, timeout=12) as resp:
            page = resp.read().decode("utf-8", errors="replace")
        title_match = re.search(r'<title[^>]*>(.*?)</title>', page, re.I | re.S)
        title = re.sub(r'\s+', ' ', title_match.group(1)).strip() if title_match else "未能读取标题"
        title = title.replace("_哔哩哔哩_bilibili", "").strip()
        # Extract basic JSON-LD/meta descriptions when publicly present
        desc_match = re.search(r"<meta[^>]+name=[\"']description[\"'][^>]+content=[\"'](.*?)[\"']", page, re.I | re.S)
        desc = desc_match.group(1).replace("&quot;", '"').replace("&amp;", "&") if desc_match else ""
        result["text"] = f"{title}\\n{desc}"
        result["summary"] = (
            f"页面标题：{title}\\n\\n"
            f"页面描述：{desc[:1200] if desc else '未从公开页面提取到描述。'}\\n\\n"
            "说明：此功能只尝试读取公开可访问的网页元信息，不会绕过登录、验证码或访问限制。"
        )
    except Exception as exc:
        result["summary"] = (
            "无法自动读取此链接的公开页面信息。\\n"
            f"原因：{type(exc).__name__}: {exc}\\n\\n"
            "你仍可以在浏览器中打开视频，并在后续版本中导入合法取得的字幕文件或攻略文本。"
        )
    return result
