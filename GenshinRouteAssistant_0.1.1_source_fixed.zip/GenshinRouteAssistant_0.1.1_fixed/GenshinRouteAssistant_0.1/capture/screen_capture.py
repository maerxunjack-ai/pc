import mss
import numpy as np

class ScreenCapture:
    def list_screens(self):
        with mss.mss() as sct:
            # mss[0] is the virtual desktop; real displays begin at 1
            return [
                {
                    "index": i - 1,
                    "width": sct.monitors[i]["width"],
                    "height": sct.monitors[i]["height"],
                    "x": sct.monitors[i]["left"],
                    "y": sct.monitors[i]["top"],
                }
                for i in range(1, len(sct.monitors))
            ]

    def capture(self, index):
        with mss.mss() as sct:
            monitors = sct.monitors[1:]
            if index < 0 or index >= len(monitors):
                return None
            shot = np.array(sct.grab(monitors[index]))
            return shot[:, :, :3]
