from PySide6.QtWidgets import QApplication
from interface.main_window import MainWindow
import sys

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Genshin Route Assistant")
    window = MainWindow()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
