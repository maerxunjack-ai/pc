from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QComboBox, QTextEdit, QGroupBox, QFormLayout, QMessageBox
)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QPixmap, QImage
from capture.screen_capture import ScreenCapture
from research.bilibili_search import inspect_bilibili_url
from research.guide_analyzer import analyze_guide_text
import numpy as np

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Genshin Route Assistant 0.1")
        self.resize(1180, 780)
        self.capture = ScreenCapture()
        self._build_ui()
        self._populate_screens()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_previews)
        self.timer.start(700)

    def _build_ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)

        title = QLabel("Genshin Route Assistant 0.1")
        title.setStyleSheet("font-size: 22px; font-weight: 700;")
        subtitle = QLabel("双屏预览 · 攻略信息检查 · 路线任务草稿（当前版本不控制游戏）")
        subtitle.setStyleSheet("color: #666;")
        layout.addWidget(title)
        layout.addWidget(subtitle)

        screen_box = QGroupBox("双屏选择与预览")
        screen_layout = QVBoxLayout(screen_box)
        selectors = QHBoxLayout()
        self.game_screen = QComboBox()
        self.video_screen = QComboBox()
        selectors.addWidget(QLabel("游戏屏幕："))
        selectors.addWidget(self.game_screen, 1)
        selectors.addWidget(QLabel("视频屏幕："))
        selectors.addWidget(self.video_screen, 1)
        reload_btn = QPushButton("重新检测显示器")
        reload_btn.clicked.connect(self._populate_screens)
        selectors.addWidget(reload_btn)
        screen_layout.addLayout(selectors)

        previews = QHBoxLayout()
        self.game_preview = QLabel("等待捕获游戏屏幕")
        self.video_preview = QLabel("等待捕获视频屏幕")
        for label in (self.game_preview, self.video_preview):
            label.setMinimumSize(420, 235)
            label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            label.setStyleSheet("border: 1px solid #999; background: #202020; color: white;")
            previews.addWidget(label, 1)
        screen_layout.addLayout(previews)
        layout.addWidget(screen_box)

        guide_box = QGroupBox("B 站攻略信息")
        guide_layout = QVBoxLayout(guide_box)
        row = QHBoxLayout()
        self.url_input = QComboBox()
        self.url_input.setEditable(True)
        self.url_input.addItem("https://b23.tv/oGhQ908")
        self.url_input.setMinimumWidth(550)
        inspect_btn = QPushButton("检查链接信息")
        inspect_btn.clicked.connect(self.inspect_guide)
        row.addWidget(QLabel("视频链接："))
        row.addWidget(self.url_input, 1)
        row.addWidget(inspect_btn)
        guide_layout.addLayout(row)
        self.guide_output = QTextEdit()
        self.guide_output.setReadOnly(True)
        self.guide_output.setPlaceholderText("这里会显示可获取的链接信息和分析提示。")
        self.guide_output.setMaximumHeight(145)
        guide_layout.addWidget(self.guide_output)
        layout.addWidget(guide_box)

        task_box = QGroupBox("路线任务草稿")
        task_layout = QVBoxLayout(task_box)
        self.task_output = QTextEdit()
        self.task_output.setReadOnly(True)
        self.task_output.setPlainText(
            "尚未分析攻略。\n\n建议流程：\n"
            "1. 检查视频标题、章节和可用字幕。\n"
            "2. 将路线分解为传送、移动、解谜、战斗、收集等任务。\n"
            "3. 为每项任务记录来源时间戳、前置条件和完成判据。\n"
            "4. 未验证的解法标记为“待验证”，不直接当成事实。"
        )
        task_layout.addWidget(self.task_output)
        layout.addWidget(task_box, 1)

        footer = QLabel("隐私与安全：仅捕获你选择的显示器；此原型不读取游戏内存、不注入进程，也不发送游戏输入。")
        footer.setWordWrap(True)
        footer.setStyleSheet("color: #555;")
        layout.addWidget(footer)

    def _populate_screens(self):
        current_game = self.game_screen.currentData() if self.game_screen.count() else None
        current_video = self.video_screen.currentData() if self.video_screen.count() else None
        self.game_screen.clear()
        self.video_screen.clear()
        screens = self.capture.list_screens()
        for idx, info in enumerate(screens):
            label = f"显示器 {idx + 1} — {info['width']}×{info['height']} ({info['x']},{info['y']})"
            self.game_screen.addItem(label, idx)
            self.video_screen.addItem(label, idx)
        if screens:
            self.game_screen.setCurrentIndex(current_game if isinstance(current_game, int) and current_game < len(screens) else 0)
            default_video = 1 if len(screens) > 1 else 0
            self.video_screen.setCurrentIndex(current_video if isinstance(current_video, int) and current_video < len(screens) else default_video)
        self.refresh_previews()

    def refresh_previews(self):
        screens = self.capture.list_screens()
        if not screens:
            self.game_preview.setText("没有检测到显示器")
            self.video_preview.setText("没有检测到显示器")
            return
        self._set_preview(self.game_preview, self.game_screen.currentData())
        self._set_preview(self.video_preview, self.video_screen.currentData())

    def _set_preview(self, label, idx):
        if idx is None:
            return
        frame = self.capture.capture(int(idx))
        if frame is None:
            label.setText("捕获失败")
            return
        # Ensure the image buffer is C-contiguous before passing it to Qt.
        frame = np.ascontiguousarray(frame)
        h, w, ch = frame.shape
        image = QImage(frame.data, w, h, ch * w, QImage.Format.Format_BGR888).copy()
        pix = QPixmap.fromImage(image).scaled(label.size(), Qt.AspectRatioMode.KeepAspectRatio,
                                               Qt.TransformationMode.SmoothTransformation)
        label.setPixmap(pix)

    def inspect_guide(self):
        url = self.url_input.currentText().strip()
        if not url:
            QMessageBox.warning(self, "缺少链接", "请先输入 B 站视频链接。")
            return
        self.guide_output.setPlainText("正在检查链接……")
        QApplication.processEvents()
        result = inspect_bilibili_url(url)
        self.guide_output.setPlainText(result["summary"])
        self.task_output.setPlainText(analyze_guide_text(result.get("text", "")))

