@echo off
setlocal
py -3 -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
pip install pyinstaller
pyinstaller --noconfirm --clean --windowed --name GenshinRouteAssistant app.py
echo.
echo Build finished if no errors appeared. EXE: dist\GenshinRouteAssistant\GenshinRouteAssistant.exe
pause
