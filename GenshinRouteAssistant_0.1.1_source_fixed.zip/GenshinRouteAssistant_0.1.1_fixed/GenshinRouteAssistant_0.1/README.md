# Genshin Route Assistant 0.1 (Prototype)

Windows 11 dual-monitor desktop prototype for screen preview and guide metadata inspection.

## Current capabilities
- Detects connected monitors and lets the user select game/video displays.
- Shows live previews of both selected displays.
- Attempts a best-effort fetch of publicly accessible Bilibili page metadata.
- Displays a route-analysis placeholder for follow-on subtitle parsing.

## Important limitations
- This is a prototype, not a finished autonomous game agent.
- It does not control the game.
- It does not read or modify game memory, inject into the game process, or modify game files.
- It does not bypass login, CAPTCHA, DRM, or site access restrictions.
- Bilibili may restrict automated page access; if so, import of a subtitle file can be added as the next step.
- No prebuilt EXE is included in this source package. Build it on Windows using `build.bat`.

## Requirements
- Windows 10/11
- Python 3.11 recommended
- Two displays in Windows Extend mode (one display also works for testing)

## Run from source
```bat
py -3 -m venv .venv
call .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

## Build EXE
Run `build.bat` from Windows. PyInstaller will place the executable under `dist\\GenshinRouteAssistant\\`.

## First test
1. Start the app.
2. Choose the display containing the game.
3. Choose the display containing the video.
4. Verify both preview windows show the expected screens.
5. Paste the Bilibili URL and click "检查链接信息".

## Next development milestones
1. Local subtitle import (.srt/.vtt/.txt) and timestamped segment extraction.
2. Public Bilibili metadata/chapters support where accessible.
3. Route task extraction with provenance and confidence labels.
4. Visual landmark/puzzle recognition.
5. Character capability knowledge base and task planner.
6. Only after rule review, evaluate permitted input automation.
